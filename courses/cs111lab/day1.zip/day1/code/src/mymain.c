#include<stdio.h>
int main()
{
  int x = 0, y = 3;
  float p = 2.5, q;
  q = 1.2;
  x = p*q+y;
  printf("Result = %f", x);
  return 0;
}