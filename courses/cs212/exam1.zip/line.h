using namespace std;
class Line
{
    private:
	  Point startP;
	  Point endP;
    public:

	  //constructors and destructor
	  Line();
	  Line(Point p1, Point p2);
	  Line(const Line &OtherLine);
	  ~Line();

	  //getters and setters
	  void SetStart (const Point SomePoint);
	  void SetEnd (const Point SomePoint);
	  Point GetStart() const;
	  Point GetEnd() const;
	  double GetSlope() const;
	  double GetIntercept() const;

	  //other useful methods
	  Line operator+(double); // Translate a line by a fixed amount
	  void rotate(double,Point); // Rotate a line about a pivot point by a given angle
	  double CalculateDistance (Point SomePoint) const; // Calculate the distance of the line from a point

	  // Overloaded stream operators
	  friend ostream& operator<<(ostream&, const Line&); // Prints the equation of the line in y = mx + c format
};
