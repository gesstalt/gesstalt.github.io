using namespace std;
class Point {
    private:
        double Xcoord;
        double Ycoord;
    public:
        //constructors and destructor
        Point(double, double);
        Point(const Point &OtherPoint);
        ~Point();

        // getters and setters
        void SetXCoordinate(const double Value);
        void SetYCoordinate(const double Value);
        double GetXCoordinate() const;
        double GetYCoordinate() const;

        //other useful methods
        void rotatePoint(double); // Rotate a point by a given angle as parameter
        float CalculateDistance(const Point OtherPoint) const; // Calculate distance from another point given as parameter
        Point& operator+(double); // Translate a point by a fixed amount given as parameter in both x and y direction

        // Overloaded stream operators
        friend ostream& operator<<(ostream&, const Point&); // Prints the location of a point as (Xcoord,Ycoord) format
};
