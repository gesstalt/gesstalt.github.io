/**
* Create GradeBook class and display message
*/

#include<iostream>
#include<string>
using namespace std;

// GradeBook class definition
class GradeBook{
public:
    // Function to show welcome message
    void displayMessage(){
        cout << "Welcome to the gradebook for " << getCourseName() << "!" << endl;
    }
    // Getter function
    string getCourseName(){
        return courseName;
    }
    // Setter function
    void setCourseName(string name){
        courseName = name;
    }
private:
    string courseName;// Course name of this gradebook
};

int main(){
    string nameOfCourse;
    GradeBook myGradeBook; // create a GradeBook object named myGradeBook
    cout << "Please enter the course name : " << endl;
    getline(cin,nameOfCourse);
    myGradeBook.setCourseName(nameOfCourse);
    cout << endl;
    myGradeBook.displayMessage(); // call object's displayMessage function
    return 0;
}
