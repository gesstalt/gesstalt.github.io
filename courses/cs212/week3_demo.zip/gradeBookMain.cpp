/**
* Create GradeBook class and display message
*/

#include<iostream>
#include<string>
using namespace std;

#include "gradeBook.cpp"


int main(){
    string nameOfCourse;
    GradeBook myGradeBook; // create a GradeBook object named myGradeBook
    cout << "Please enter the course name : " << endl;
    getline(cin,nameOfCourse);
    myGradeBook.setCourseName(nameOfCourse);
    cout << endl;
    myGradeBook.displayMessage(); // call object's displayMessage function
    return 0;
}
