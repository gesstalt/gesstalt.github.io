/**
* Create GradeBook class and display message
*/

#include<iostream>
#include<string>
using namespace std;

#include "gradeBook.h"

void GradeBook:: displayMessage(){
    cout << "Welcome to the gradebook for " << getCourseName() << "!" << endl;
}

string GradeBook::getCourseName(){
    return courseName;
}

void GradeBook::setCourseName(string name){
    courseName = name;
}
