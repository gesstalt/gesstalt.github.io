/**
* Create GradeBook class and display message
*/

#include<iostream>
#include<string>
using namespace std;

// GradeBook class definition
class GradeBook{
public:
    // Function to show welcome message
    void displayMessage(string courseName){
        cout << "Welcome to the gradebook for " << courseName << "!" << endl;
    }
};

int main(){
    string nameOfCourse;
    GradeBook myGradeBook; // create a GradeBook object named myGradeBook
    cout << "Please enter the course name : " << endl;
    getline(cin,nameOfCourse);
    cout << endl;
    myGradeBook.displayMessage(nameOfCourse); // call object's displayMessage function
    return 0;
}
