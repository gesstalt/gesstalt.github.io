/**
* Create GradeBook class and display message
*/

// GradeBook class definition
class GradeBook{
public:
    // Function to show welcome message
    void displayMessage();
    // Getter function
    string getCourseName();
    // Setter function
    void setCourseName(string name);
private:
    string courseName;// Course name of this gradebook
};
