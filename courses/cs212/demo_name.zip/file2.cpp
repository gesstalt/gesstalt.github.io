/* This is file2.cpp */

	namespace
	{
		// Should not collide with other files
		int local;
	}

	void func()
	{
		local = 2;
	}
