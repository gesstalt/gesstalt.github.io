// A simple example that uses typeid.
#include <iostream>
#include <typeinfo>
using namespace std;
class myclass1 {
// ...
};
class yourclass2 {
// ...
};
int main()
{
    int i, j;
    float f;
    char *p;
    myclass1 ob1;
    yourclass2 ob2;
    cout << "The type of i is: " << typeid(i).name();
    cout << endl;
    cout << "The type of f is: " << typeid(f).name();
    cout << endl;
    cout << "The type of p is: " << typeid(p).name();
    cout << endl;
    cout << "The type of ob1 is: " << typeid(ob1).name();
    cout << endl;
    cout << "The type of ob2 is: " << typeid(ob2).name();
    cout << "\n\n";
    if(typeid(i) == typeid(j))
        cout << "The types of i and j are the same\n";
    if(typeid(i) != typeid(f))
        cout << "The types of i and f are not the same\n";
    if(typeid(ob1) != typeid(ob2))
        cout << "ob1 and ob2 are of differing types\n";
    return 0;
}
