/*This is file1.cpp*/
	#include<iostream>
    #include "file2.cpp"

	using namespace std;

	namespace file1
	{
		int local;
	}

	void func();

	int main()
	{
		file1::local = 1;
		cout << "Local=" << local << endl;
		func();
		cout << "Local=" << local << endl;
		return 0;
	}
