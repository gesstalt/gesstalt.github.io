#include<iostream>
using namespace std;

class complex
{

    int real,comp;
    public:

        complex(){}

        void getvalue(){
                 cout << "Enter the Real Component:";
                 cin  >> real;
                 cout << "Enter the Complex Component:";
                 cin >> comp;
       }

    void operator++(int y){
                 real=++real;
                 comp=++comp;
       }



       void operator--(int x){
                 real=--real;
                 comp=--comp;
        }
        void display(){
                 cout<<real<<"+\t"<<comp<<"i"<<endl;
         }

};



int main(){

     complex obj;

     obj.getvalue();

     obj.display();

     obj++;

     cout<<"Increment Complex Number\n";

     obj.display();

     obj--;

     cout<<"Decrement Complex Number\n";

     obj.display();

}
