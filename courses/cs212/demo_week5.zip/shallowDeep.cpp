#include<iostream>
using namespace std;

class myClass{
private:
    int mySize;
    int *myArray;
public:
    myClass(){
        cout<<"Inside default constructor"<<endl;
        mySize=1;
        myArray = new int[mySize];
    }
    myClass(int s){
        cout<<"Inside constructor"<<endl;
        mySize = s;
        myArray = new int[mySize];
    }
    void initialize(int val){
        myArray[0]=val;
    }
    int getArray0(){return myArray[0];}

    myClass(const myClass &ob){
        cout << "Inside copy constructor"<< endl;
    }
};

int main(){
    myClass ob1(5);
    ob1.initialize(25);
    {
        myClass ob2 = ob1;
    }
    cout<<"My Value = "<<ob1.getArray0()<<endl;
    myClass ob3;
    ob3=ob1;
    cout<<"My Value = "<<ob3.getArray0()<<endl;
}
