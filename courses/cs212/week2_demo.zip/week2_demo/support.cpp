#include <iostream>

extern int count;

void write_extern(void)
{
   std::cout << "Count is " << count << '\n';
}


