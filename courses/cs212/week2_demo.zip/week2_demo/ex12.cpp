/**
* Example of loop control statements
*/

#include <iostream>
using namespace std;

int main()
{
    for(int i=5;i>=1;i--){
        for(int j=1;j<=i;j++){
            cout << "*";
        }
        cout << "\n";
    }

    return 0;
}

//int main()
//{
//    int i=1;
//    while(i<=5){
//        int j=1;
//        while(j<=i){
//            cout << "*";
//            j++;
//        }
//        cout << "\n";
//        i++;
//    }
//
//    return 0;
//}

//int main()
//{
//    int i=1;
//    do{
//        int j=5;
//        do{
//            cout << "*";
//            j--;
//        }while(j>=i);
//        cout <<endl;
//        i++;
//    }while(i<=5);
//    return 0;
//}


