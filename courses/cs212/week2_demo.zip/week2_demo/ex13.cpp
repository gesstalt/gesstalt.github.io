#include<iostream>
using namespace std;

void printStars(int);

int main()
{
    int number;
    cout << "Enter the number of lines in the grid: ";
    cin >> number;
    printStars(number);
    cout << endl << "Grid Pattern Complete - End of Program.";
    return 0;
} // end of main

void printStars(int num){
    if (num < 0){
        cout << endl << "Please enter a non negative number." << endl;
    } // End if
    else{
        if (num == 0){
            return;
        } // End if
        else{
                for (int q = 1; q <= num; q++){
                cout << "*";
                }
                cout << endl;
                printStars(num - 1);
                for (int q = 1; q <= num; q++){
                    cout << "*";
                }
                cout << endl;
        } // End else
    } // End else
} // end printStars
