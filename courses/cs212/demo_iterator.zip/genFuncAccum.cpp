#include<iostream>
#include<vector>
#include<numeric>
using namespace std;

int main(){
    cout << "Demonstrating accumulate function" << endl;
    int x[5]={1 , 3, 5 , 7 , 9};
    vector<int> vector1(&x[0],&x[0]);
    int sumI = accumulate(vector1.begin(),vector1.end(),0);
    cout << "Sum (Integer) = " << sumI << endl;
    double y[5]={1.5 , 3.5, 5.5 , 7.5 , 9.5};
    double sumD = accumulate(&y[0],&y[5],0.0);
    cout << "Sum (double) = " << sumD << endl;
    return 0;
}
