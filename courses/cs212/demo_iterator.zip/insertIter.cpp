// insert_iterator example
#include <iostream>     // std::cout
#include <iterator>     // std::insert_iterator
#include <list>         // std::list
#include <algorithm>    // std::copy
using namespace std;

int main () {
  list<int> foo, bar;
  for (int i=1; i<=5; i++)
  { foo.push_back(i); bar.push_back(i*10); }

  list<int>::iterator it = foo.begin();
  advance(it,3);

  insert_iterator< list<int> > insert_it (foo,it);

  copy (bar.begin(),bar.end(),insert_it);

  cout << "foo:";
  for ( list<int>::iterator it = foo.begin(); it!= foo.end(); ++it )
	  cout << ' ' << *it;
 cout << '\n';

  return 0;
}
