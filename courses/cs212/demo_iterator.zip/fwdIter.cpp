#include<iostream>
#include<cassert>
#include<algorithm>
#include<list>
#include<iterator>
using namespace std;

int main(){
    int a[10]= {2,5,15,-5,12,20,14,7,66,44};

    for (int i=0;i<10;i++)
        cout << "a["<<i+1<<"] = " <<a[i]<<endl;
    replace(&a[0],&a[10],-5,55);
    cout <<"After replace"<<endl;
    for (int i=0;i<10;i++)
        cout << "a["<<i+1<<"] = " <<a[i]<<endl;
}
