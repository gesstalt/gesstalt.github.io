#include<iostream>
#include<algorithm>
#include<iterator>
using namespace std;

int main(){
    int a[10]= {2,5,15,-5,12,20,14,7,66,44};
    int *ptr = find(&a[0],&a[10],7);
    cout << "We have " << *ptr << " followed by " << *(ptr+1) <<"."<< endl;

    cout<<"Type some character including an x followed\n by at least one non-whitespace character: "<< endl;

    istream_iterator<char> in(cin);
    istream_iterator<char> eos; // End of stream iterator
    find(in,eos,'x');

    cout <<"The first non-white space character following\n"
    <<"the first 'x' was '"<< *(++in) << "'."<<endl;
    return 0;
}
