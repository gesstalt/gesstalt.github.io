#include <memory>
#include <iostream>
#include <string>
using namespace std;
int main()
{
    allocator<int> a1; // default allocator for ints
    int* a = a1.allocate(10); // space for 10 ints

    a[9] = 7;

    cout << a[9] << '\n';

    a1.deallocate(a, 10);

    // default allocator for strings
    allocator<string> a2;
    string* s = a2.allocate(2); // space for 2 strings

    a2.construct(s, "foo");
    a2.construct(s + 1, "bar");

    cout << s[0] << ' ' << s[1] << '\n';

    a2.destroy(s);
    a2.destroy(s + 1);
    a2.deallocate(s, 2);
}
