#include<iostream>
#include<cassert>
#include<algorithm>
#include<list>
#include<iterator>
using namespace std;

int main(){
    int a[10]= {2,5,15,-5,12,20,14,7,66,44};
    int b[10];
    copy(&a[0],&a[10],&b[0]);

    for (int i=0;i<10;i++)
        cout << "b["<<i+1<<"] = " <<b[i]<<endl;

    return 0;
}
