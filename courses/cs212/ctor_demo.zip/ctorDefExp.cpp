#include<iostream>
#include<string>
using namespace std;

class File
{
private:
    string path;
    int mode;
public:
    File(){}
    File(const string& file_path, int open_mode){}
    ~File(){}
};

int main(){
    File folder1[10];
    File folder2[2] = { File("f1", 1)};
    File folder3[3] = { File("f1", 1), File("f2",2), File("f3",3) };
}
