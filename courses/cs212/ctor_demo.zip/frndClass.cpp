/**
* Example of friend class
*/

#include<iostream>
using namespace std;

class TwoValues{
    int val1;
    int val2;
public:
    void setTwoValues(int v1, int v2 ){val1 = v1; val2=v2;}
    friend class CalMin;
};

class CalMin{
public:
    int min(TwoValues temp){
        return temp.val1 < temp.val2 ? temp.val1:temp.val2;
    }
};

int main(){
    TwoValues myTwoVal;
    myTwoVal.setTwoValues(10,20);
    CalMin myMin;
    cout << "Min of two values is = " << myMin.min(myTwoVal)  << endl;
    return 0;
}
