#include<iostream>
using namespace std;
class MyClass
{
public:
    MyClass();  // constructor declared
    int getData(){return x;}

private:
    int x;
};


int main()
{
    MyClass m;  // at runtime, object m is created, and the default constructor is called
    cout << "Default value assigned = " << m.getData() << endl;
    return 0;
}
