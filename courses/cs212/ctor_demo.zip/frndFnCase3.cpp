/**
* Demo: Friend function, case 3
*/

#include<iostream>
using namespace std;

const int IDLE = 0;
const int INUSE = 1;

class OtherClass; // Forward declaration

class MyClass{
    int status;
public:
    void setStatus(int state){status = state;};
    friend int chkIdle(MyClass ob1, OtherClass ob2);
};

class OtherClass{
    int status;
public:
    void setStatus(int state);
    friend int chkIdle(MyClass ob1, OtherClass ob2);
};

void OtherClass::setStatus(int state){
    status = state;
}

int chkIdle(MyClass ob1, OtherClass ob2){
    if(ob1.status || ob2.status) return 0;
    else return 1;
}

int main(){
    MyClass myObj;
    OtherClass othrObj;

    myObj.setStatus(IDLE);
    othrObj.setStatus(IDLE);

    if(chkIdle(myObj,othrObj)) cout << "Screen can be used" << endl;
    else cout << "In use" << endl;

    myObj.setStatus(INUSE);

    if(chkIdle(myObj,othrObj)) cout << "Screen can be used" << endl;
    else cout << "In use" << endl;

    return 0;
}
