#include<iostream>
using namespace std;

class Example{

    // Variable Declaration

    int a,b;

    public:
    //Constructor
    Example(int x,int y){
        // Assign Values In Constructor
        a=x;
        b=y;
        cout<<"I'm in Constructor\n";
    }

    void Display(){
        cout<<"Values : "<<a<<"\t"<<b << endl;
    }
};

int main(){
    Example Object(10,20);
    // Constructor invoked.
    Object.Display();
    Example ob1 = Example(30,40);
    ob1.Display();
    return 0;
}
