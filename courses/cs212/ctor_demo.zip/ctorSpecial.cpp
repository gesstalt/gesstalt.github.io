#include <iostream>
using namespace std;
class X {
    int a;
public:
    X(int j) { a = j; }
    int geta() { return a; }
};
int main()
{
    X ob = 99;
    cout << ob.geta();
    return 0;
}
