#include <iostream>
  using namespace std;

  int main()
  {
    int j;
    int i;

    i = 0;
    while (1) {
      i++;
      cin >> j;
      if (cin.fail()) return 0;
      cout << "Integer " << i << ": " << j << endl;
    }
  }
