///**
//* C++ Formatted I/O
//*/
//
//#include <iostream>
//using namespace std;
//
//int main(void)
//{
//cout<<"Welcome to C++ I/O module!!!"<<endl;
//cout<<"Welcome to ";
//cout<<"C++ module on I/O"<<endl;
// //endl is end line stream manipulator
// //issue a new line character and flushes the output buffer
//// output buffer may be flushed by cout<<flush; command
//}
//
//#include <iostream>
//using namespace std;
//
//int main(void)
//{
//int p = 3, q = 10;
//
//cout << "Concatenating using << operator.\n"
//     <<"--------------------------------"<<endl;
//cout << "70 minus 20 is "<<(70 - 20)<<endl;
//cout << "55 plus 4 is "<<(55 + 4)<<endl;
//cout <<p<<" + "<<q<<" = "<<(p+q)<<endl;
//}
//
//#include <iostream.h>
//using namespace std;
//
//int main(void)
//{
//int p, q, r;
//
//cout << "Enter 3 integers separated by space: \n";
//cin>>p>>q>>r;
//// the >> operator skips whitespace characters such as tabs,
//// blank space and newline.  When eof is encountered, zero (false) is returned.
//cout<<"Sum of the "<<p<<","<<q<<" and "<<r<<" is = "<<(p+q+r)<<endl;
//}
//
//// end of file controls depend on system
//// Ctrl-z followed by return key - IBM PC, Ctrl-d - UNIX and MAC
//#include <iostream>
//using namespace std;
//
//int main(void)
//{
//char p;
//
//cout <<"Using member functions get(), eof() and put()\n"
//     <<"---------------------------------------------"<<endl;
//cout<<"Before any input, cin.eof() is "<<cin.eof()<<endl;
//cout<<"Enter a line of texts followed by end of file control: "<<endl;
//
//while((p = cin.get()) !=EOF)
//    cout.put(p);
//cout<<"\nAfter some text input, cin.eof() is "<<cin.eof()<<endl;
//}
//
//// another get() version
//#include <iostream>
//using namespace std;
//
//const int SIZE = 100;
//
//int main(void)
//{
//char bufferOne[SIZE], bufferTwo[SIZE];
//
//cout <<"Enter a line of text:"<<endl;
//cin>>bufferOne;
//// store the string in array bufferOne
//// just the first word in the array string, then the
//// first whitespace encountered
//cout<<"\nThe line of text read by cin>> was:"<<endl;
//cout<<bufferOne<<endl;
//cin.get(bufferTwo, SIZE);
//// the rest of the string
//cout<<"The line of text read by cin.get(bufferTwo,SIZE) was:"<<endl;
//cout<<bufferTwo<<endl;
//}
//
//// getline() example
//#include <iostream>
//using namespace std;
//
//const SIZE = 100;
//
//int main(void)
//{
//char buffer[SIZE];
//
//cout<<"Read by cin.getline(buffer, SIZE)\n"
//    <<"--------------------------------\n"<<"Enter a line of text:"<<endl;
//cin.getline(buffer, SIZE);
//cout<<"The line of text entered is: "<<endl;
//cout<<buffer<<endl;
//}
//
//// using read(), write() and gcount() member functions
//#include <iostream>
//using namespace std;
//
//const int SIZE = 100;
//
//void main(void)
//{
//char buffer[SIZE];
//
//cout<<"Enter a line of text:"<<endl;
//cin.read(buffer,45);
//cout<<"The line of text entered was: "<<endl;
//cout.write(buffer, cin.gcount());
//// the gcount() member function returns
//// the number of unformatted characters last extracted
//cout<<endl;
//}
//
//// using hex, oct, dec and setbase stream manipulator
//#include <iostream>
//using namespace std;
//#include <iomanip>
//
//int main(void)
//{
//int p;
//
//cout<<"Enter a decimal number:"<<endl;
//cin>>p;
//cout<<p<< " in hexadecimal is: "
//<<hex<<p<<'\n'
//<<dec<<p<<" in octal is: "
//<<oct<<p<<'\n'
//<<setbase(10) <<p<<" in decimal is: "
//<<p<<endl;
//cout<<endl;
//}
//
//
//// using precision and setprecision
#include <iostream>
using namespace std;
#include <iomanip>
// using C++ wrappers to access C function
#include <cmath>

int main(void)
{
double theroot = sqrt(11.55);

cout<<"Square root of 11.55 with various"<<endl;
cout<<"           precisions"<<endl;
cout<<"---------------------------------"<<endl;
cout<<"Using 'precision':"<<endl;
for(int poinplace=0; poinplace<=8; poinplace++)
{
cout.precision(poinplace);
cout<<theroot<<endl;
}
cout<<"\nUsing 'setprecision':"<<endl;
for(int poinplace=0; poinplace<=8; poinplace++)
cout<<setprecision(poinplace)<<theroot<<endl;
}
//
//// using width member function
//#include <iostream>
//using namespace std;
//
//int main(void)
//{
//       int p = 6;
//       char string[20];
//
//       cout<<"Using field width with setw() or width()"<<endl;
//       cout<<"----------------------------------------"<<endl;
//       cout<<"Enter a line of text:"<<endl;
//       cin.width(7);
//       while (cin>>string)
//       {
//              cout.width(p++);
//              cout<<string<<endl;
//              cin.width(7);
//              // use ctrl-z followed by return key or ctrl-d to exit
//       }
//}
//
//
