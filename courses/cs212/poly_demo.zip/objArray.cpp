#include<iostream>
using namespace std;

class books{
private:
    char title;
    float price ;
public:
    void getdata ();
    void putdata ();
};

void books :: getdata (){
    cout<<"Title:";
    cin>>title;
    cout<<"Price:";
    cin>>price;
}

void books :: putdata (){
    cout<<"Title:"<<title<< "\n";
    cout<<"Price:"<<price<< "\n";
}

int main (){
    const int size=3;
    books book[size];
    for(int i=0;i<size;i++){
        cout<<"Enter details of book "<<(i+1)<<"\n";
        book[i].getdata();
    }
    for(int i=0;i<size;i++){
        cout<<"\nBook "<<(i+1)<<"\n";
        book[i].putdata();
    }
    return 0;
}
