// sort algorithm example
#include <iostream>
#include<iterator>
#include <algorithm>
#include <vector>
using namespace std;

bool myfunction (int i,int j) { return (i<j); }

int main () {
  int myints[] = {32,71,12,45,26,80,53,33};
  vector<int> myvector (myints, myints+8);               // 32 71 12 45 26 80 53 33
  ostream_iterator<int> out_it (cout," ");

  // print out content:
  cout << "myvector before sort:\n";
  copy ( myvector.begin(), myvector.end(), out_it );
  cout << "\n\n";

  // using default comparison (operator <):
  sort (myvector.begin(), myvector.begin()+4);           //(12 32 45 71)26 80 53 33

    // print out content:
  cout << "myvector after default sort:\n";
  copy ( myvector.begin(), myvector.end(), out_it );
  cout << "\n\n";

  // using default comparison (operator <):
  sort (myvector.begin()+4, myvector.end(),greater<int>());           //(12 32 45 71)26 80 53 33

    // print out content:
  cout << "myvector after using predicate function:\n";
  copy ( myvector.begin(), myvector.end(), out_it );
  cout << "\n\n";
  // using function as comp
  sort (myvector.begin()+4, myvector.end(), myfunction); // 12 32 45 71(26 33 53 80)

   // print out content:
  cout << "myvector after myfunction:\n";
  copy ( myvector.begin(), myvector.end(), out_it );
  cout << "\n\n";

  return 0;
}
