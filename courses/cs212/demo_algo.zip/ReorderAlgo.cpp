// Reordering algorithm example
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

int main () {
  int myints[] = {32,71,12,45,26,80,53,33};
  vector<int> myvector (myints, myints+8);               // 32 71 12 45 26 80 53 33
  /**
  * Example of sort
  */
  cout << "myvector contains before sort:";
  for (vector<int>::iterator it=myvector.begin(); it!=myvector.end(); ++it)
    cout << ' ' << *it;
  cout << '\n';
  // using default comparison (operator <):
  sort (myvector.begin(), myvector.begin()+4);           //(12 32 45 71)26 80 53 33
  // print out content:
  cout << "myvector contains after first sort:";
  for (vector<int>::iterator it=myvector.begin(); it!=myvector.end(); ++it)
    cout << ' ' << *it;
  cout << '\n';
  sort (myvector.begin()+4, myvector.end()); // 12 32 45 71(26 33 53 80)
  cout << "myvector contains after second sort:";
  for (vector<int>::iterator it=myvector.begin(); it!=myvector.end(); ++it)
    cout << ' ' << *it;
  cout << '\n';
  // Sorting the entire content
  sort (myvector.begin(), myvector.end()); // 12 32 45 71(26 33 53 80)
  cout << "myvector contains after third sort:";
  for (vector<int>::iterator it=myvector.begin(); it!=myvector.end(); ++it)
    cout << ' ' << *it;
  cout << "\n\n";

  /**
  * Example of random_shuffle
  */
  // Shuffling the vector
  random_shuffle(myvector.begin(), myvector.end());
  cout << "myvector contains after Shuffling:";
  for (vector<int>::iterator it=myvector.begin(); it!=myvector.end(); ++it)
    cout << ' ' << *it;
  cout << '\n';

  /**
  * Example of rotate
  */
  rotate(myvector.begin(), myvector.begin() + 2, myvector.end());
  cout << "myvector contains after rotation:";
  for (vector<int>::iterator it=myvector.begin(); it!=myvector.end(); ++it)
    cout << ' ' << *it;
  cout << '\n';
  return 0;
}
