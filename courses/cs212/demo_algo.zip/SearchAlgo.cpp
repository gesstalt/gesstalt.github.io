// Search algorithms example
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

int main () {
  int myints[] = { 10, 40, 30, 20 };
  int * p;

  /**
  * Example of find() algorithm
  */
  p = find (myints, myints+4, 30);
  if (p != myints+4)
    cout << "Element found in myints: " << *p << '\n';
  else
    cout << "Element not found in myints\n";

  // using find with vector and iterator:
  vector<int> myvector (myints,myints+4);
  vector<int>::iterator it;

  it = find (myvector.begin(), myvector.end(), 30);
  if (it != myvector.end())
    cout << "Element found in myvector: " << *it << '\n';
  else
    cout << "Element not found in myvector\n";

  cout << "looking for a 30... ";
  if (binary_search (myvector.begin(), myvector.end(), 30))
    cout << "found!\n";
  else
    cout << "not found.\n";

  sort(myvector.begin(),myvector.end());

  cout << "looking for a 30... after sort:  ";
  if (binary_search (myvector.begin(), myvector.end(), 30))
    cout << "found!\n";
  else
    cout << "not found.\n";
  return 0;
}
