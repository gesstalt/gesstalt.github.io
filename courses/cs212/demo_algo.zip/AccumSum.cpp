// accumulate example
#include <iostream>
#include <numeric>
#include<vector>
using namespace std;

int main () {
  int init = 100;
  int numbers[] = {10,20,30,40,50,60,70,80,90};

  cout << "using default accumulate on integer arrays: ";
  cout << accumulate(numbers,numbers+sizeof(numbers)/sizeof(int),0);
  cout << '\n';

  vector<int> v(numbers,numbers+sizeof(numbers)/sizeof(int));
  cout << "using default accumulate of vector: ";
  cout << accumulate(v.begin(),v.end(),init);
  cout << '\n';

  cout << "Sum of part of the vector: ";
  cout << accumulate(v.begin()+2,v.end()-2,0);
  cout << '\n';

  return 0;
}
