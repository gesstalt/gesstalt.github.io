#include <string>
#include <cstring>
#include <set>
#include <iostream>
#include <iterator>
#include <fstream>
using namespace std;
const char* delimiters = " \t;()\"<>:{}[]+-=&*#.,/\\~";

int main(int argc, char* argv[]) {
    ifstream in("myfile.txt");
    set<string> wordlist;
    string line;
    while(getline(in, line)) {
        // Capture individual words:
        char* s = // Cast probably won’t crash:
        strtok((char*)line.c_str(), delimiters);
        while(s) {
        // Automatic type conversion:
            wordlist.insert(s);
            s = strtok(0, delimiters);
        }
    }
    // Output results:
    copy(wordlist.begin(), wordlist.end(),ostream_iterator<string>(cout, "\n"));
}
