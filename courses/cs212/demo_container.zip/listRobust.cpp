//: C04:ListRobustness.cpp
// lists are harder to break
#include <list>
#include <iostream>
using namespace std;
int main() {
    list<int> li(100, 0);
    cout << "Size of the list = " << li.size() << endl;
    list<int>::iterator i = li.begin();
    for(int j = 0; j < li.size() / 2; j++)
        i++;
    // Walk the iterator forward as you perform
    // a lot of insertions in the middle:
    for(int k = 0; k < 1000; k++)
        li.insert(i++, 1); // No problem
    cout << "Size of the list after so many insertion = " << li.size() << endl;
    cout<<"Last element = " << *i << endl;
    li.erase(i);
    li.insert(i,200);
    i=li.end();
    cout<<"Last element = " << *i << endl;
    i++;
    *i = 2; // Oops! It's invalid
}
