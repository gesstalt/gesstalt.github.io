#include "Useful.h"
#include <iostream>
using namespace std;

class Y : public X {
    int i; // Different from X's i
public:
    Y() { i = 0; }
    int change() {
        i = permute(); // Different name call
        return i;
    }
    void setValue(int ii) {
        i = ii;
        X::setValue(i); // Same-name function call
    }
};
int main() {
    cout << "sizeof(X) = " << sizeof(X) << endl;
    cout << "sizeof(Y) = " << sizeof(Y) << endl;
    Y D; // Creating derived class object
    cout <<"Changed value of derived data member = " << D.change() << endl;
    // X function interface comes through:
    cout << "Element = " << D.read() << endl;
    // Redefined functions hide base versions:
    cout << "After permutation of base data member = " << D.permute() << endl;
    D.setValue(12);
    cout << "Element = " << D.read() << endl;
    D.permute();
    cout << "Element = " << D.read() << endl;
}
