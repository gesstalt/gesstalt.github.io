#include<iostream>
using namespace std;
class X {
    int i;
public:
    X() { i = 0; }
    void setValue(int ii) { i = ii; }
    int read() const { return i; }
    int permute() { return i = i * 47; }
};
