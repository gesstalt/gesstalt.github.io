#include <iostream>
using namespace std;
class base {
private:
    int i;
public:
    base(int x) { i=x; cout << "Constructing base\n"; }
    int getX(){return i;}
    ~base() { cout << "Destructing base\n"; }
};
class derived: public base {
    int j;
public:
// derived uses x; y is passed along to base.
    derived(int x, int y): base(y){
        j=x; cout << "Constructing derived\n";
    }
    ~derived() { cout << "Destructing derived\n"; }
    void show() { cout << getX() << " " << j << "\n"; }
};

int main()
{
    derived ob(3, 4);
    ob.show(); // displays 4 3
    return 0;
}
