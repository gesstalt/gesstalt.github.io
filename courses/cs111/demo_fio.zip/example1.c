#include<stdio.h>

int main(){
  int x;
  float y;
  char z;
  char arr[10];
  printf("\nEnter an Integer: ");

  scanf("%d",&x);
  printf("\nYou have entered: %d",x);
  printf("\nNow enter a 2 digit number: ");
  scanf("%2d",&x);
  printf("\nYou have entered: %d",x);
  printf("\nEnter a character: ");
  scanf("%c",&z);
  printf("\nYou have entered: %c",z);
  printf("\nEnter 3 characters: ");
  scanf("%3c",&z);
  printf("\nYou have entered: %c",z);
  printf("\nEnter a real number: ");
  scanf("%3f",&y);
  printf("\nYou have entered: %f",y);
}
