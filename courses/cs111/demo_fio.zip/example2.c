#include<stdio.h>

int main(){
  int myInt=23, myNegInt = -12;
  float myFloat = 45.123;
  char myChar = 'x';
  char myString[] = "IIT Jodhpur";
  printf("\nOperating on Integer");
  printf("\n%d \n%0d \n%3d \n%04d \n%2.5d",  myInt,  myInt,  myInt,  myInt,  myInt); 
  printf("\n%d \n%0d \n%3d \n%04d \n%2.5d",  myNegInt,  myNegInt,  myNegInt,  myNegInt,  myNegInt); 
  printf("\nOperating on Float");
  printf("\n%f \n%0f \n%3f \n%04f \n%2.5f",  myFloat,  myFloat,  myFloat,  myFloat,  myFloat); 
  printf("\nOperating on Characters");
  printf("\n%c \n%0c \n%3c \n%04c \n%2.5c",  myChar,  myChar,  myChar,  myChar,  myChar);
  printf("\nOperating on Strings");
  printf("\n%s \n%0s \n%20s \n%04s \n%2.5s",  myString,  myString,  myString,  myString,  myString);
}
