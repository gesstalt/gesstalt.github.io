#include <stdio.h>
int main(int argc, char *argv[]){
    int n;
    n = argc;
    while(argc-- > 0)
        printf("argv[%d] is %s\n",n-(argc+1),*argv++);        
    return 0;
}