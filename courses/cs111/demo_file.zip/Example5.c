#include <stdio.h>
int main(void){
    FILE *fp;
    char line[100];
    fp = fopen("Example5.c", "r");
    while(fgets(line,100,fp)!=NULL){
        printf("%s\n",line);
    }
    fclose(fp);
    return 0;
}