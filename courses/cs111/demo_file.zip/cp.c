#include <stdio.h>
#include <stdlib.h>
void filecopy(FILE *ifp, FILE *ofp)
{
    int c;
    while((c=getc(ifp))!= EOF)
        putc(c,ofp);
}

main(int argc, char *argv[]){
    FILE *fp,*fp1;
    char *prog = argv[0];
    void filecopy(FILE *, FILE *);
    if(argc != 3)
    {
        fprintf(stderr,"fewer arguments\n");
        exit(1);   
    } 
    else
    {
        if((fp = fopen(*++argv, "r"))== NULL){
            fprintf(stderr,"%s: cannot open %s\n",prog,*argv);
                exit(1);
        }
        if((fp1 = fopen(*++argv, "w"))== NULL){
                    fprintf(stderr,"%s: cannot open %s\n",prog,*argv);
                    exit(1);
        }
        filecopy(fp,fp1);
        fclose(fp1);
        fclose(fp);
    }
    return 0;
}