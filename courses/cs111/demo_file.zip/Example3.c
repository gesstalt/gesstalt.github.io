#include <stdio.h>

int main(void){
    int n,m, sum;
    FILE *fp;
    fp = fopen("Output", "a+");
    printf("enter two numbers: ");
    scanf("%d%d",&n,&m);
    sum = m+n;
    fprintf(fp,"Sum = %d\n",sum);
    fclose(fp);
    return 0;
}