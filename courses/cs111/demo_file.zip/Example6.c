#include <stdio.h>

int main(void){
    const int MAXLEN = 20;
    char line[MAXLEN];
    fgets(line,20,stdin);
    printf("You typed \"%s\"\n",line);
    return 0;
}