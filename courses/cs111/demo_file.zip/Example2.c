#include <stdio.h>
#include<stdlib.h>
int main(void){
    int n,m, sum;
    FILE *fp,*fp1;
    int i;
    char c;
    printf("Enter a character: ");
    c=getc(stdin);
    putc(c,stdout);
    printf("\n");
    fp = fopen("Example2.c", "r");
    if(fp==NULL){
        fprintf(stderr,"cannot open input file.\n");
        exit(1);
    }
    fp1 = fopen("Output1.dat", "a");
    while((c = getc(fp))!='\n')
        putc(c,fp1);
    fclose(fp1);
    fclose(fp);
    return 0;
}