#include <stdio.h>

int main(void){
    int n,m, sum;
    FILE *fp, *fp1;
    int i;
    fp = fopen("Input.dat", "r");
    fp1 = fopen("Output.dat", "w");
    for(i=0;i<5;i++){
    fscanf(fp,"%d%d",&n,&m);
    sum = m+n;
    fprintf(fp1,"Sum = %d\n",sum);
    }
    fclose(fp1);
    fclose(fp);
    return 0;
}