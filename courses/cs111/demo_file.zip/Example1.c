#include <stdio.h>

int main(void){
    int n,m, sum;
    scanf("%d%d",&n,&m);
    sum = m+n;
    printf("Sum = %d\n",sum);
    return 0;
}