#include<stdio.h>
#include<math.h>
main()
{ 
    float coeff1, coeff2, coeff3;
    float root1, root2, discrim, denom;
    printf("Enter the 1st coefficient:");  /* prompt */
    scanf("%f",&coeff1);     /* read and store */
    printf("Enter the 2nd coefficient:");
    scanf("%f", &coeff2);
    printf("Enter the 3rd coefficient:");
    scanf("%f", &coeff3); /* Now compute the roots*/
    discrim = pow(coeff2, 2) - 4*coeff1*coeff3;
    denom = 2*coeff1;
    root1 = (- coeff2 + sqrt(discrim))/denom;
    root2 = (- coeff2 - sqrt(discrim))/denom;
    printf("the roots were %f, %f \n", root1, root2);
}