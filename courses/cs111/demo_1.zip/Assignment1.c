#include<stdio.h>
main()
{
  int a=10;
  float b=5.0;
  int c = 8;
  printf("c=%d b= %f a=%d\n",c=b, b=a, a=c);
}
