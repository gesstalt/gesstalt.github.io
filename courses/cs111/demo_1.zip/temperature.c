#include<stdio.h>
main()
{
  float f=10;
  float c = 8;
  scanf("%f",&f);
  c=(f-32)/9*5;
  printf("c=%f",c);
}
