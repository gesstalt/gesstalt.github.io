#include<stdio.h>
int main()
{
    int x=10, y;
    float z = 10.55678;
    printf("x = %d\n");
    printf("x = %d z = %10.3e\n",x,z);
    printf("z = %10.3f\n",z);
}
