#include <stdio.h>
int main()
{
int a=10, b=5;
int x, y=6, z;
    printf("Enter a\n");
    scanf("%d",&a);
x= y= z= a+b;
printf("x= %d y=%d z=%d\n",x, y, z);
}
