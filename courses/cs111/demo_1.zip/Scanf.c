#include<stdio.h>
int main()
{
    int x,y;
    char c = 'A';
    printf("x= %d y = %d\n",x,y);
    printf("Enter x and y\n");
    x=c;
    scanf("%d%d",&x,&y);
    printf("x= %c y = %d\n",x,y);
    printf("decimal value of c = %d\n",c);
}
