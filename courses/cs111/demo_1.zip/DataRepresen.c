#include<stdio.h>
int main()
{
    int x=35;
    long int y = -10;
    printf("x= %d x= %o x= %x y=%x\n",x,x,x,y);
}
