#include<stdio.h>
int main(){
  int n=23; char c='d'; float pi=3.141592654; char *s1 = " a short string";
  printf("%c,\n",c);        /* 7(a) */
  printf("%10c,\n",c);      /* 7(b) */
  printf("%-10c,\n",c);     /* 7(c) */
  printf("%d,\n",n);        /* 7(d) */
  printf("%10d,\n",n);      /* 7(e) */
  printf("%-10d,\n",n);     /* 7(f) */
  printf("%010d,\n",n);	    /* 7(g) */
  printf("%4.2d, \n",n);
  printf("%o,\n",n);        /* 7(h) */
  printf("%8o,\n",n);       /* 7(i) */
  printf("%08o,\n",n);      /* 7(j) */
  printf("%-8x,\n",n);      /* 7(k) */
  printf("%f,\n",pi);       /* 7(l) */
  printf("%4.2f,\n",pi);    /* 7(m) */
  printf("%10.4f,\n",pi);   /* 7(n) */
  printf("%16.1f,\n",pi);   /* 7(o) */
  printf("%-16.1f,\n",pi);  /* 7(p) */
  printf("%e,\n",pi);       /* 7(q) */
  printf("%16.1e,\n",s1);   /* 7(r) */
  printf("%s,\n",s1);       /* 7(t) */
  printf("%4s,\n",s1);      /* 7(u) */
  printf("%-20s,\n",s1);    /* 7(v) */
  printf("%25s,\n",s1);     /* 7(w) */
  printf("%-20.8s,\n",s1);  /* 7(x) */
  printf("%20.8s,\n",s1);   /* 7(y) */
  printf("%06d,\n",n);      /* 7(z) */
}
