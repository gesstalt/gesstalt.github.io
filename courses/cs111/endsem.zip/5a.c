#include <stdio.h>
int main(){
  int var = 010;
  printf("%d", var);
}
