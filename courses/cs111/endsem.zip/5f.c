#include <stdio.h>
int main(){
  int a = 10, b = 5, c = 5;
  int d;
  d = a == (b + c);
  printf("%d", d);
}
