#include<stdio.h>
void reverse(void){
  int c;
  if ((c=getchar())!='\n') reverse() ;
  putchar(c); 
}
int main(){
  printf ("Enter Text ") ;  printf ("\n") ;
  reverse();  
  printf ("\n") ;
}
