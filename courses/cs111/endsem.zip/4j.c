#include<stdio.h>
int main(){
  int x=1;
  do{
    printf("Hello World \n");
    if(x==5)
      break;
    x++;
  }while(1);
}
