#include <stdio.h>
main()
{
    int a[]={1,2,3,4,5,6,7,8,9,10};
    int i;
    for(i=0;i<10;i++)
        printf("a[%d] : %d\n",i,a[i]);
    return 0;
}