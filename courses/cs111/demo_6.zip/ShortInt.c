#include<stdio.h>
main()
{
    short int Short_hd;
    printf("Enter a short int\n");
    scanf("%hd",&Short_hd);
    printf("Short_hd = %hd\n",Short_hd);
}
