#include <stdio.h>
main()
{
    int coeff[20], n, x, value, i;
    printf("Enter the degree and evaluation point:\n");
    scanf("%d%d",&n,&x); 
    printf("Enter the coefficients\n");
    for(i=0;i<=n;i++)
        scanf("%d",&coeff[i]);
    value = coeff[n];
    for(i=n-1;i>=0;i--)
        value = x*value+coeff[i];
    printf("The value of p(%d) is %d\n",x, value);
    return 0;
}