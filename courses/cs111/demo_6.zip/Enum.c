#include<stdio.h>
main()
{
    enum booleam {No, Yes=12};
    printf("No = %d Yes = %d\n",No, Yes);
}
