#include<stdio.h>
main()
{
    char c1 = '1', c2 = '2', c3;
    c3 = c1 + c2;
    printf("c3 = %c\n",c3);
}
