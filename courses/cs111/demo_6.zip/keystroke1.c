#include<stdio.h>
//#include<stdlib.h>
main()
{
int i,num,count[256]={0};
char ch;
puts("enter d number of times a any character can be inputted");
scanf("%d",&num);

 for(i=0;;i++)
 {
  puts("enter any character: ");
     getchar();
     scanf("%c",&ch);
    if(count[(unsigned int)ch]!=num)
  {
      count[(unsigned int)ch]++;
  }

  else
  {
   puts("loop exits");
   break;
  }

 }

}




