#include<stdio.h>
#include<string.h>
main()
{
    char str[20] = "CS1100";
    char str1[] = {'C', 'R', 'C', '1', '0', '2', '\0'};
    char str2[10] = "IIT Madras";
    char str3[10], c,s[20];
    int StrLength,n;
    StrLength = strlen(str1);
    printf("String1 = %s\nString2 = %s\nLength of String1 = %d\n",str, str1,StrLength);
    if(strcmp(str,str1)!=0) printf("strings are not  same\n");
    else printf("Strings are same\n");
    printf("Enter the number of characters to be compared: ");
    scanf("%d",&n);
    if(strncmp(str,str1,n)!=0) printf("strings are not  same\n");
    else printf("the first %d character(s) is(are) same\n",n);
    printf("str after concatenation: %s\n",strcat(str,str1));
    printf("Enter the number of characters to be concatenated: ");
    scanf("%d",&n);
    strncat(str, str1, n);
    printf("str after n-concatenation: %s\n",str);
    strcpy(str,str1);
    printf("str after copy: %s\n",str);
    printf("Enter the number of characters to be copied: ");
    scanf("%d",&n);
    strncpy(str, str2, n);
    printf("str after n-copy: %s\n",str);
    strncpy(str3, str2, n);
    printf("str3 after n-copy: %s\n",str3);
    printf("Enter a character to locate in string \"%s\": ", str1);
    getchar();
    c= getchar();
    printf("character %c is first appeared at location %s in string \"%s\"\n",c,strchr(str1,c),str1);
    printf("Enter a string to locate in string \"%s\": ", str1);
    scanf("%s",s);
    printf("String %s is first appeared at location %s in string \"%s\"\n",s,strstr(str1,s),str1);
}
