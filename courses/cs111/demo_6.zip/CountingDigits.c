#include <stdio.h>
main()
{
    int c, i, nWhite, nOther, nDigit[10];
    nWhite = nOther = 0;
    for(i=0;i<10;i++)nDigit[i]=0;
    printf("Enter the Text:\n");
    while((c=getchar())!=EOF){
        //printf("c = %c and %d\n",c,c);
        switch(c){
            case '0':case '1':case '2':case '3':case '4':case '5':
            case '6':case '7':case '8':case '9': nDigit[c-'0']++; break;
            case' ': case'\n': case '\t': nWhite++; break;
            default: nOther++; break;
        }
    }
    printf("Digits: \n");
    for(i=0;i<10;i++)
        printf("%d occurred %d times \n", i, nDigit[i]);
    printf("White spaces: %d, other: %d\n", nWhite, nOther);
    return 0;
}