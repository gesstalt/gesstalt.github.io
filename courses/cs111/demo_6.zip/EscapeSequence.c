#include<stdio.h>
main()
{
    char a = '\v';   //'\b','\n','\r','\t','\v', '\a', '\f'
    printf("CS1100");
    printf("%c",a);
    printf("CRC102\n");
}
