#include<stdio.h>
main()
{
    const int j = 25;
    //const char MESG[] = "how are you?";
    j = j*10;
    printf("j = %d\n",j);
    //MESG[4]='a';
    //printf("MESG = %s\n",MESG);
}
