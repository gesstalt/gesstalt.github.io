#include<stdio.h>

enum months{Jan = 1, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec};
    
main()
{
    enum months month;
    const char monthName[13][20]={"","January","February","March","April", "May", "June", "July", "August","September", "October", "November", "December"};
    for(month=Jan; month<= Dec; month++)
        printf("%2d%11s\n",month,monthName[month]);
}
