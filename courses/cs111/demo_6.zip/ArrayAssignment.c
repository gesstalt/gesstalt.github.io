#include <stdio.h>
main()
{
    int i, a[]={2,3,4}, b[3];
    b = a;
    for(i=0;i<3;i++)
        printf("b[%d] : %d\n",i,b[i]);
    return 0;
}