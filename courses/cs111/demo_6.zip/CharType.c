#include<stdio.h>
main()
{
    int i;
    char c = 0xC7;
    unsigned char sc = 0xC7;
    printf("%d %d\n",c, sc);
}
