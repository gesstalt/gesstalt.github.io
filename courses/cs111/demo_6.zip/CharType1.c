#include<stdio.h>
main()
{
    char c;
    c = getchar();
    printf("%d %d %d\n",'0',c,c-'0');
}
