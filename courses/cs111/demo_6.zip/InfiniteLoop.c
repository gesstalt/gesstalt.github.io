#include<stdio.h>
main()
{
    char c;
    for(c=-128;c<=127;c++)
        printf("%d -- %c\n", c);
}
