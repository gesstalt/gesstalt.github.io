#include<stdio.h>
main()
{
    int octal_num=013;
    int hexa_num=0x13;
    int num1, num2;
    printf("Octal_num = %d, Hexa_num = %d\n",octal_num, hexa_num);
    printf("Enter two numbers:\n");
    scanf("%o %x",&num1, &num2);
    printf("Number1 = %d Number2 = %d\n", num1, num2);
}
