#include<stdio.h>
main()
{
    char str[] = "CS1100";
    char str1[] = {'C', 'R', 'C', '1', '0', '2', '\0'};
    printf("String = %s\n %s\n %d %d\n",str, str1,str[6],'\0');
}
