#include <stdio.h>
#define M 10
main()
{
    int i,n;
    //int a[M];
    printf("Enter n: ");
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    for(i=0;i<n;i++)
        printf("a[%d] : %d\n",i,a[i]);
    return 0;
}