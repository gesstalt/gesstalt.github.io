#include<stdio.h>
main()
{
    int Char_c, Short_hd, Int_d, LongInt_ld, Float_f, Double_lf, LongDouble_Lf;
    Char_c          = sizeof(char);
    Short_hd        = sizeof(short);
    Int_d           = sizeof(int);
    LongInt_ld      = sizeof(long int);
    Float_f         = sizeof(float);
    Double_lf       = sizeof(double);
    LongDouble_Lf   = sizeof(long double);
    
    printf("%d %d %d %d %d %d %d\n",Char_c, Short_hd, Int_d, LongInt_ld, Float_f, Double_lf, LongDouble_Lf);
}
