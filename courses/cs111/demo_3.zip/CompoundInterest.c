#include <stdio.h>
#include<math.h>
main()
{
    int yr;
    double amt, principal = 1000.0, rate = .05;
    printf("%4s%10s\n", "year", "Amount");
    for(yr = 1; yr <=10; yr++){
        amt = principal*pow(1.0+rate, yr);
        printf("%4d%10.2f\n",yr,amt);
    }
    return 0;
}