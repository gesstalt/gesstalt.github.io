#include<stdio.h>
main ()
{
    int i, sum=0;
    for(i = 1; ; i = i+1) {
        if(i%2 == 0) continue;
        if(i>20) break;
        sum += i;
    }
    printf("%d is the sum\n", sum);
}
 