#include <stdio.h>
main()
{
    int i=0,j=0,k=0,l=0,m;
    char n;
    printf("Enter the letter grade ('a' or 'b' or 'c' or 'd')\n");
    printf("Enter the EOF character to end input\n"); 
    while((n= getchar())!=EOF){
        switch(n)
		{
            case 'a': i+=1; break;
            case 'b': j+=1; break;
            case 'c': k+=1; break;
            case 'd': l+=1; break; 
            default : break;
		}
	}
    printf("%d %d %d %d are the no of votes gained by a,b,c and d\n",i,j,k,l);
    printf("thanks for voting\n");	 
    return 0;
}