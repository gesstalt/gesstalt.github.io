#include <stdio.h>
#include<math.h>
main()
{
    float k;
    printf("Enter a floating-point number: ");
    scanf("%f",&k);
    printf("Floating-point number: %22.20f\n", k);
    return 0;
}