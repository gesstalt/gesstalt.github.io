#include <stdio.h>
main()
{
    int n=0, smallNum = 10000;
    printf("Enter Numbers (in the range 0 to 9999):\n");
    scanf("%d",&n); 
    while(n>=0){
        if(smallNum > n) smallNum = n;
        scanf("%d",&n);
	}
    printf("Smallest number is %d\n",smallNum);
    return 0;
}