#include<stdio.h>
#include<math.h>
main ()
{
    int n;
    float prevGuess, currGuess, error, sqRoot;
    printf("Enter a number: ");
    scanf ("%d", &n);
    currGuess = (float) n/2;
    error = 0.0001;
    do
    {
        prevGuess = currGuess;
        currGuess = (prevGuess + n/prevGuess)/2;
    }while(fabs(prevGuess - currGuess)>error);
    sqRoot = currGuess;
    printf("Root of %d is %f\n",n,sqRoot);
}
 