#include<stdio.h>
main ()
{
    int d = 2, n, sum = 1;
    printf("Enter number: ");
    scanf ("%d", &n);
    while(d <= (n/2))
    {
        if(n%d == 0) sum += d; d++;
    }
    if(sum == n) printf("%d is perfect\n", n);
    else printf("%d is not perfect\n",n);
}
 