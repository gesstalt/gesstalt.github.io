#include<stdio.h>
main()
{
    float n,m=0;
    int n1=0,n2=0,bd=0,ad=0;
    printf("ENTER ANY NUMBER\n");
    scanf("%f",&n);
    n1=(int)n;
    /*To count number of digits before decimal point*/
    while(n1>0)
    {
        bd=bd+1;
        n1=n1/10;
    }
    /*To count number of digits after decimal point*/
    m=n-n1;
    while(m>0)
    {
        ad=ad+1;
        n2=(int)(m*10);
        m=(m*10)-n2;
    }
    /*to print the values*/
    printf("\nNUMBER OF DIGITS BEFORE DECIMAL POINT= %d\n",bd);
    printf("\nNUMBER OF DIGITS AFTER  DECIMAL POINT= %d\n",ad);
}
