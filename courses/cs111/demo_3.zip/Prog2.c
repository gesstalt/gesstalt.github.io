#include <stdio.h>
main()
{
    int a,b;
    char p;
    
    printf("enter the numbers\n");
    scanf("%d %d",&a,&b);
    getchar();
    printf("specify the operation\n");
    scanf("%c",&p);
    printf("Result is :");
    switch(p)
	{
        case '+' : 
            printf("%d\n",a+b);break;
        case '-' :
            printf("%d\n",a-b);break;
        case '*' :
            printf("%d\n",a*b);break;
        case '/' : 
            printf("%d\n",a/b);break;
        default: 
            printf("invalid entry");
	}
    return 0;
}