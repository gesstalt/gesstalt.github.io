#include <stdio.h>/*prog to vote and evaluate the no of votes each of the*/
main()/*members have got*/
{
    int i=0,j=0,k=0,l=0,m;
    char n;
    printf("to vote enter 1 to exit enter 2: ");
    scanf("%d",&m);
    while(m==1)
	{
        printf("enter the member code: ");
        n=getchar();
        switch(n)
		{
            case 'a': i+=1; break;
            case 'b': j+=1; break;
            case 'c': k+=1; break;
            case 'd': l+=1; break; 
            default : break;
		}
        printf("to continue voting enter 1 or enter 2 for exit: ");
        scanf("%d",&m);
	}
    printf("%d %d %d %d are the no of votes gained by a,b,c and d\n",i,j,k,l);
    printf("thanks for voting\n");	 
    return 0;
}
