#include <stdio.h>
main()
{
    int m;
    char n;
    printf("Enter a number: ");
    scanf("%d",&m);
    getchar();
    printf("Enter Character1: ");
    scanf("%c",&n);
    printf("Character1 :%c\n",n);
    return 0;
}