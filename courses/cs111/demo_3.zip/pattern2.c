#include<stdio.h>
int main()
{
  int row,left,right,space;
  int ln;
  printf("\nEnter Line Number: ");
  scanf("%d",&ln);
  for(row=1;row<=ln;row++)
  {
    for(space=1;space<=ln-row+1;space++) printf(" ");
    for(left=row-1;left>=0;left--) printf("%d",left);
    for(right=1;right<row;right++) printf("%d",right);
    printf("\n");
  }
} 
   
