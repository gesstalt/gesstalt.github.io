#include <stdio.h>
main()
{
    int count=1;
    do{
     printf("%d\n",count);   
    }while(++count<=10);
    return 0;
}