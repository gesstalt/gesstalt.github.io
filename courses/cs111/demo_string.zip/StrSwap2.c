#include <stdio.h>
#define MAX_SIZE 40
#define MAX_STRINGS 10

int strLength(char a[])
{
    int i=0;
    while(a[i]!='\0') i++;
    return i;
}

void swap(char a[][40], int i, int j, int k)
{
    char c;
    c = a[i][k];
    a[i][k] = a[j][k];
    a[j][k] = c;
}

void subStrCopy(char A[][40], int i, int j, int k, int p){
    int l;
    for(l=k; l < p; l++)
        A[j][l] = A[i][l];
}

void arraySwap(char A[][40], int i, int j){
    int k,m,n,l;
    m = strLength(A[i]);
    n = strLength(A[j]);
    l = (m<n)?m:n;
    for(k=0; k<=l; k++)
        swap(A, i, j, k);
    if(m<n)
        subStrCopy(A,j,i,l+1,n);
    else if(n<m)
        subStrCopy(A,i,j,l+1,m);        
}


main(){
    char str[MAX_STRINGS+1][40];
    int i,j,n;
    printf("Enter the no. of strings (less than %d): ",MAX_STRINGS);
    scanf("%d",&n);
    printf("Enter the strings: \n");
    for(i=0;i<n;i++)
        scanf("%s",str[i]);
    printf("Before swap:\n");   
    for(i=0;i<n;i++)
        printf("%20s\n",str[i]);
    printf("Enter indices of the strings to be swapped: \n");
    scanf("%d%d",&i,&j);
    arraySwap(str, i, j);
    printf("After swap:\n");   
    for(i=0;i<n;i++)
        printf("%20s\n",str[i]);
}