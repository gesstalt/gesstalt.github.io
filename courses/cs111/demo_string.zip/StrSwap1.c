#include <stdio.h>
#define MAX_SIZE 40

int strLength(char a[])
{
    int i=0;
    while(a[i]!='\0') i++;
    return i;
}

void swap(char a[][40], int i, int j, int k)
{
    char c;
    c = a[i][k];
    a[i][k] = a[j][k];
    a[j][k] = c;
}

void subStrCopy(char A[][40], int i, int j, int k, int p){
    int l;
    for(l=k; l < p; l++)
        A[j][l] = A[i][l];
}

void arraySwap(char A[][40], int i, int j){
    int k,m,n,l;
    m = strLength(A[i]);
    n = strLength(A[j]);
    l = (m<n)?m:n;
    for(k=0; k<=l; k++)
        swap(A, i, j, k);
    if(m<n)
        subStrCopy(A,j,i,l+1,n);
    else if(n<m)
        subStrCopy(A,i,j,l+1,m);        
}


main(){
    char str[][40] = {"String in C", "Another string in C"};
    int n;
    printf("Before swap: %s --- %s\n", str[0], str[1]);
    arraySwap(str, 0, 1);
    printf("After swap: %s --- %s\n", str[0], str[1]);    
}