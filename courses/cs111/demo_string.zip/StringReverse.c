#include <stdio.h>
main(){
    int i = 4;
    char c;
    do{
        c = "hello"[i];
        printf("%c", c);
        i--;
    }while(i>=0);
    printf("\n");
}
