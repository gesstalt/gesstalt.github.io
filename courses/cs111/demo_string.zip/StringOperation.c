#include <stdio.h>
#define MAX_SIZE 40

int strLength(char a[])
{
    int i=0;
    while(a[i]!='\0') i++;
    return i;
}
int strCompare(char A[][40], int i, int j){
    int k = 0, n,m,l;
    n= strLength(A[i]);
    m=strLength(A[j]);
    l=(n>m)?n:m;
    while ((A[i][k] == A[j][k])&& k<l) k++;
    printf("%d\n",k);
    if(A[i][k] == '\0') return i;
    if(A[j][k] == '\0') return j;
    if(A[i][k] < A[j][k]) return i;
    else return j;
}

void arrayCopy(char A[][40], int i, int j){
    int k;
    for(k=0; k < MAX_SIZE; k++)
        A[j][k] = A[i][k];
}

void arraySwap(char A[][40], int i, int j){
    int k;
    char c;
    for(k=0; k < MAX_SIZE; k++)
    {
        c = A[i][k];
        A[i][k] = A[j][k];
        A[j][k] = c;
    }
}


main(){
    char str[][40] = {"String in C", "Another string in C"};
    int n;
    n = strCompare(str, 0, 1);
    printf("%d and %s\n", n, str[n]);
    printf("Before swap: %s --- %s\n", str[0], str[1]);
    arraySwap(str, 0, 1);
    printf("After swap: %s --- %s\n", str[0], str[1]);
    arrayCopy(str, 0, 1);
    printf("%s\n", str[1]);
}