#include <stdio.h>
main(){
    char str[][40] = {"String in C", "Another string in C"};
    int count1 = 0;
    int count2 = 0;
    while(str[0][count1]!='\0') count1++;
    while(str[1][count2]!='\0') count2++;
    if(sizeof str[0] < count1 + count2 +1)
        printf("\n Not enough space for both strings.");
    else
    {
        int i = count1, j = 0;
        while((str[0][i++] = str[1][j++])!='\0');
        printf("%s\n", str[0]);
    }
}