#include <stdio.h>
#define MAX_SIZE 40

int strLength(char a[])
{
    int i=0;
    while(a[i]!='\0') i++;
    return i;
}

void swap(char a[][40], int i, int j, int k)
{
    char c;
    c = a[i][k];
    a[i][k] = a[j][k];
    a[j][k] = c;
}

void arraySwap(char A[][40], int i, int j){
    int k;
    char c;
    for(k=0; k < MAX_SIZE; k++)
        swap(A, i, j, k);
}

main(){
    char str[][40] = {"String in C", "Another string in C"};
    int n;
    printf("Before swap: %s --- %s\n", str[0], str[1]);
    arraySwap(str, 0, 1);
    printf("After swap: %s --- %s\n", str[0], str[1]);    
}