#include <stdio.h>
int strLength(char a[])
{
    int i=0;
    while(a[i]!='\0') i++;
    return i;
}

void swap(char a[], int i, int j)
{
    char c;
    c = a[i];
    a[i] = a[j];
    a[j] = c;
}

main(){
    int i, n;
    char c[40];
    printf("Enter a string: ");
    scanf("%s",c);
    n=strLength(c);
    for(i=0;i<n/2;i++)
        swap(c,i,n-1-i);
    printf("Reverse string: %s\n",c);
}
