#include<stdio.h>
int main()
{
  int roomNo=308;
  printf("\nAddress of variable = %u",&roomNo);
  printf("\nValue of Variable = %d",roomNo);
  printf("\nValue of Variable (using indirection) = %d",*(&roomNo));
}
