#include<stdio.h>
int main()
{
  int roomNo=308;
  int *roomNoPtr = &roomNo;
  printf("\nAddress of variable = %u",&roomNo);
  printf("\nValue of Variable (using indirection) = %d",*(&roomNo));
  printf("\nNext Integer is at = %u",&roomNo+1); 
  printf("\nNext to Next Integer is at = %u",&roomNo+2);
  printf("\nUsing Pointer: Value = %d",*roomNoPtr);
  printf("\nUsing Pointer: Address = %u",roomNoPtr);
}
