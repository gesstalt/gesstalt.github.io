#include<stdio.h>
int main()
{
  int roomNo=308;
  printf("\nAddress of variable = %u",&roomNo);
  printf("\nValue of Variable (using indirection) = %d",*(&roomNo));
  printf("\nNext Integer is at = %u",&roomNo+1); 
  printf("\nNext to Next Integer is at = %u",&roomNo+2);
}
