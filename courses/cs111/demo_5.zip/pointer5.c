#include<stdio.h>
int main()
{
  int roomNo=308;
  float marks = 45.66;
  char code = 'C';
  int *roomNoPtr = &roomNo;
  float *marksPtr = &marks;
  char *codePtr = &code;
  printf("\nUsing Pointer: Value = %d",*roomNoPtr);
  printf("\nUsing Pointer: Address = %u",roomNoPtr);
  printf("\nUsing pointer: Value (Float) = %f",*marksPtr);
  printf("\nUsing pointer: Address (Float) = %u", marksPtr);
}
