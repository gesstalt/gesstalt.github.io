#include<stdio.h>
int main()
{
  int roomNo=308;
  char code = 'C';
  int *roomNoPtr = &roomNo,*temp2;
  char *codePtr = &code;
  char *temp ;
  printf("\nUsing Pointer: Value = %d",*roomNoPtr);
  printf("\nUsing Pointer: Address = %u",roomNoPtr);
  printf("\nUsing pointer: Value (Char) = %c",*codePtr);
  printf("\nUsing pointer: Address (Char) = %u", codePtr);
}
