#include<stdio.h>
void swapVal(int *var1, int *var2);
int main()
{
  int roomNo=308,doorNo=2;
  printf("\nBefore Swap: roomNo = %d, doorNo = %d",roomNo,doorNo);
  swapVal(&roomNo,&doorNo);
  printf("\nAfter Swap: roomNo = %d, door No = %d", roomNo, doorNo);
}
 void swapVal(int *v1,int *v2)
{
  int temp;
  temp = *v1;
  *v1 = *v2;
  *v2 = temp;
}
