#include <stdio.h>

struct student{         
    char name[20];
    int marks;
};

struct subject{         
    struct student s1;
    struct student s2;
    float avg;
}cs1100;

float Average(struct student st1,struct student st2)
{
    return (st1.marks + st2.marks)/2.0;
}

int main(void){
    int marks;
    printf("Enter quiz2 marks:\n");
    printf("Name of a student: ");
    scanf("%s",cs1100.s1.name);
    printf("%s\'s marks: ",cs1100.s1.name);
    scanf("%d",&cs1100.s1.marks);
    printf("Name of a student: ");
    scanf("%s",cs1100.s2.name);
    printf("%s\'s marks: ",cs1100.s2.name);
    scanf("%d",&cs1100.s2.marks);
    cs1100.avg = Average(cs1100.s1,cs1100.s2);    
    printf("CS1100 quiz2 marks\n");
    printf("Name\t\t Marks\n");
    printf("%s\t\t %d\n",cs1100.s1.name,cs1100.s1.marks);
    printf("%s\t\t %d\n",cs1100.s2.name,cs1100.s2.marks);
    printf("Average marks: %f\n",cs1100.avg);
    return 0;
}