#include <stdio.h>
#include <string.h>

struct student{         
    char name[20];
    int marks;
};

struct subject{         
    struct student s1;
    struct student s2;
    float avg;
}cs1100;

void Modify_subject(struct subject *sub)
{
    strcpy((*sub).s1.name,"DEF");
    (*sub).s2.marks = 1.5*((*sub).s2.marks);
}
void Modify_student(struct student *stu)
{
    (*stu).marks = 1.5*((*stu).marks);
}
void Modify_marks(float *marks)
{
    *marks = 1.5*(*marks);
}

int main(void){
    int marks;
    struct subject cs1100 = {{"Abc",40},{"Xyz",60}, 50}; 
    Modify_subject(&cs1100);    
    Modify_student(&cs1100.s1);    
    Modify_marks(&cs1100.avg);    
    printf("CS1100 quiz2 marks\n");
    printf("Name\t\t Marks\n");
    printf("%s\t\t %d\n",cs1100.s1.name,cs1100.s1.marks);
    printf("%s\t\t %d\n",cs1100.s2.name,cs1100.s2.marks);
    printf("Average is %f\n",cs1100.avg);
    return 0;
}