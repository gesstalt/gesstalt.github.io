#include <stdio.h>
#include<string.h>
struct student{         
    char name[20];
    int marks;
};

struct student getInfo(char Name[], int Marks)
{
    struct student st1;
    strcpy(st1.name, Name);
    st1.marks = Marks;
    return st1;
}

int main(void){
    struct student s1,s2;
    char Name[20] = "Abc";
    int Marks = 24;
    s1 = getInfo(Name,Marks);
    s2 = s1;
    printf("Name      : %s\n",s2.name);
    printf("%s\' marks: %d\n",s2.name,s2.marks);
    return 0;
}