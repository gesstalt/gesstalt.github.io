#include <stdio.h>

struct point{
    int x;
    int y;
};

struct rectangle{
    struct point pt1;
    struct point pt2;
};

struct point makePoint(int a, int b)
{
    struct point p;
    p.x = a;
    p.y = b;
    return p;
}

struct point addPoints(struct point p1, struct point p2)
{
    p1.x+= p2.x;
    p1.y+= p2.y;
    return p1;
}

struct rectangle screen;
struct point newPoint;

int main(void){
    screen.pt1 = makePoint(2,5);
    screen.pt2 = makePoint(16,24);
    newPoint = addPoints(screen.pt1, screen.pt2);
    printf("pt1:(%d, %d), pt2:(%d, %d), and newPoint:(%d, %d)\n",screen.pt1.x,screen.pt1.y,screen.pt2.x,screen.pt2.y,newPoint.x,newPoint.y);
    return 0;
}