#include <stdio.h>

struct point{
    int x;
    int y;
};

struct rectangle{
    struct point pt1;
    struct point pt2;
};

struct point makePoint(int a, int b)
{
    struct point p;
    p.x = a;
    p.y = b;
    return p;
}

struct rectangle screen;
struct point middle;

int main(void){
    screen.pt1 = makePoint(0,0);
    screen.pt2 = makePoint(16,24);
    middle = makePoint((screen.pt1.x + screen.pt2.x)/2,(screen.pt1.y+screen.pt2.y)/2);
    printf("Middle point of (%d, %d) and (%d, %d) is (%d,%d)\n",screen.pt1.x,screen.pt1.y,screen.pt2.x,screen.pt2.y,middle.x,middle.y);
    return 0;
}