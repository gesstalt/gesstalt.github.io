#include<stdio.h>
int main()
{
  int num1,num2;
  printf("Enter two numbers : ");
  scanf("%d%d",&num1,&num2);
  printf("\n The Numbers you entered are %d and %d\n", num1,num2);
  if(num1>num2)
  {
    printf(" Number 1 is greater than Number 2\n");
  }
  else
  {
    printf(" Number 2 is greater than Number 1\n");
  }
  return 0;
}
