#include<stdio.h>
int main()
{
  int num1,num2,num3;
  printf("Enter three numbers : ");
  scanf("%d%d%d",&num1,&num2,&num3);
  printf("\n The Numbers you entered are %d %d and %d\n", num1,num2,num3);
  if(num1>num2)
  {
    if(num1>num3)
    {
      printf("Number 1 is the largest among the three");
    }
    else
    {
      printf("Number 3 is the largest number");
    }
  }
  else
  {
    if(num2>num3)
    {
      printf("Number 2 is the largest number");
    }
    else
    {
      printf("Number 3 is the largest number");
    } 
  }
  return 0;
}
