#include<stdio.h>
int main()
{
  int num1,num2,num3,flag;
  printf("Enter three numbers : ");
  scanf("%d%d%d",&num1,&num2,&num3);
  printf("\n The Numbers you entered are %d %d and %d\n", num1,num2,num3);
  if(num1>num2 && num1>num3)
  {
      flag = 1;
  }
  if(num2>num1 && num2>num3)
  {
    flag = 2;
  }
  if(num3>num1 && num3>num2)
  {
    flag = 3;
  }
  printf("The largest among the three is %d\n", flag);
  return 0;
}
