#include <stdio.h>
int myArray[][3] = {20,24,17,4,5,100};
int main(void){
    int i,j;
    printf("%15p\n",myArray);
    printf("\n");
    for(i=0;i<2;i++)
        printf("%15p\n",myArray+i); 
    printf("\n");
    for(i=0;i<2;i++)
    {
        for(j=0;j<3;j++)
            printf("%15p",*(myArray+i)+j); 
            //printf("%15p",*myArray+3*i+j); 
        printf("\n");
    }
    printf("\n");
    for(i=0;i<2;i++)
    {
        for(j=0;j<3;j++)
            printf("%15d",*(*(myArray+i)+j)); 
        printf("\n");
    }
    printf("\n");
    printf("size of the array : %d bytes\n", (int)sizeof(myArray));
    printf("\n");
    printf("size of a row of the array :%d bytes\n", (int)sizeof(*myArray));
    printf("\n");
    printf("size of an element in a row of the array: %d bytes\n", (int)sizeof(**myArray));
    printf("\n");
    return 0;
}