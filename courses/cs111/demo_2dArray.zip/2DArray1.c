#include <stdio.h>
int myArray[][3] = {20,24,17,4,5,100};
int main(void){
    int i, j;
    printf("\n");
    for(i=0;i<2;i++)
    {
        for(j=0;j<3;j++)
        //    printf("%15p",*(myArray+i)+j); 
        printf("%15p",*myArray+3*i+j); 
        printf("\n");
    }

    printf("\n%p\n",(*myArray+1));
    printf("\n%p\n",(myArray+1));
    
    printf("\n%d\n",**myArray+1);
    printf("\n%d\n",*(*myArray+1));
    printf("\n%d\n",**(myArray+1));
    int **p;
    p = (int **)myArray;
    printf("\n%p\n",p+1);
    int *q;
    q = (int *)myArray[1];
    printf("\n%p\n",q+2);
    return 0;
}